"""Check exported inquiry-file structure; never grade the scientific answer."""
from pathlib import Path
import json

files=list(Path('submissions').glob('*.json'))
for path in files:
    data=json.loads(path.read_text(encoding='utf-8'))
    assert data.get('schema')=='inem-embedded-ai-workshop/1', path
    assert type(data.get('group')) is int and 1<=data['group']<=7, path
    assert type(data.get('mission')) is int and 1<=data['mission']<=7, path
    assert isinstance(data.get('fields'),dict), path
    assert all(isinstance(k,str) and isinstance(v,str) and len(v)<=2000 for k,v in data['fields'].items()), path
print(f'Format checked: {len(files)} file(s). Scientific content and device performance require human review.')
