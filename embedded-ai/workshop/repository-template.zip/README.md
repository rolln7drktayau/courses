# Student inquiry repository

Invite the teacher account **rolln7drktayau**. This is a blank evidence structure, not a solved network.
Place exported group JSON files in `submissions/`, raw CSV in `raw/`, plots in `figures/` and source code in `src/` if doing the full-day extension. Keep an experiment manifest in `experiments/`.

Milestones: `docs: record initial hypothesis`, `experiment: add raw observations and conditions`, `review: record peer objection`, `docs: revise conclusion and next test`.

Write numerical tests and inference yourself. Prefer English names, comments and commit messages. Required tests for a coded experiment: hand-calculated nominal input, zero input, varied input, reference/variant equivalence with a justified tolerance. Add `python -m unittest discover -s tests -v` or your language's test command to CI once real tests exist. The supplied CI validates JSON structure only; it does not validate scientific conclusions, timings or device safety.

Run the provided format check with `python tools/check_evidence.py`. It permits an empty initial repository and does not grade answers. A useful final submission must also contain evidence, sources, peer criticism and limitations. Do not commit private identifiers or invent data. The class repository can assemble the Markdown/HTML after human review.
