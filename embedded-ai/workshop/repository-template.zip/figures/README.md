Figures generated from identified raw files; label illustrative data explicitly.
