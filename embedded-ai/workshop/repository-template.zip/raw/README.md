Unedited observations, with units and conditions. Browser observations are not MCU measurements.
