Place your exported group-01.json ... group-07.json here.
