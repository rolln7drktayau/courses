Your code goes here for the full-day experiment or the later project.
