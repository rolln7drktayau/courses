Write meaningful numerical and equivalence tests for your implementation. No model implementation or expected TD solution is supplied here.
