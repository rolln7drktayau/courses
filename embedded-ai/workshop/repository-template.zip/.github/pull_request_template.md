## Question and claim

## Evidence and conditions

## Checks performed

## Peer objection and revision

## Limits and next test
