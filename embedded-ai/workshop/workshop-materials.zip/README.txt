Open embedded-ai/workshop/index.html. No installation is required. Local drafts are not synchronised; export JSON. Online source links need Internet.
